/* 
 -- READ THIS --

- You can change the server feature in index.html file and find the feature part / feature area
- You can change your server about in index.html file and find the about part / about us area

 -- CHANGE THE WEBSITE OPTION IN BELOW --
*/
let option = {
    server_name: "NightTooia",
    server_description: "NightTopia Private Server",
    owner: [
        "Dolphin"
    ],
    discord_invite_link: "https://chat.whatsapp.com/JHZ2biauTuNBWB71l6A8hY",
    ip_address: "47.129.2.226",
    host_for_android: "https://www.mediafire.com/file/pedd2za5k4djpp0/SurvivePS.txt/file"
}

